import arcade
import random
import sqlite3
from arcade.particles import FadeParticle, Emitter, EmitInterval
import arcade.future.background as background

# Размер окна
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN_TITLE = 'Miami Racer'

# Размер пиксель арта в меню
PIXEL_SCALE = 3

# Масштабирование
ORIGINAL_BG_LAYER_HEIGHT_PX = 240
SCALED_BG_LAYER_HEIGHT_PX = ORIGINAL_BG_LAYER_HEIGHT_PX * PIXEL_SCALE

# Полосы
LANE_1_Y = 150  # Нижняя полоса
LANE_2_Y = 300  # Средняя полоса
LANE_3_Y = 450  # Верхняя полоса

# Текстура для частиц
PARTICLE_TEX = arcade.make_soft_circle_texture(8, arcade.color.WHITE)


class Database:
    def __init__(self):
        self.conn = sqlite3.connect('game_records.db')
        self.cursor = self.conn.cursor()
        self.db()

    def db(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                score INTEGER NOT NULL
            )
        ''')
        self.conn.commit()

    def get_best_score(self):
        self.cursor.execute('SELECT MAX(score) FROM records')
        result = self.cursor.fetchone()[0]
        return result if result is not None else 0

    def add_score(self, score):
        self.cursor.execute('INSERT INTO records (score) VALUES (?)', (score,))
        self.conn.commit()

    def close(self):
        self.conn.close()


class Instruction(arcade.View):
    def __init__(self, previous_view):
        super().__init__()
        self.previous_view = previous_view

    def on_draw(self):
        self.clear()
        arcade.draw_lrbt_rectangle_filled(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, (20, 10, 40, 220))

        arcade.draw_text('УПРАВЛЕНИЕ', SCREEN_WIDTH // 2, SCREEN_HEIGHT - 80,
                         arcade.color.GOLD, 36, anchor_x='center')

        controls = [
            ('W / UP', 'Переместиться на полосу выше'),
            ('S / DOWN', 'Переместиться на полосу ниже'),
            ('R / L SHIFT', 'Рывок (ускорение на 1 сек, КД 5 сек)'),
            ('SPACE', 'Пауза / Продолжить'),
            ('R', 'Перезапустить игру (после столкновения)'),
            ('ESC', 'Вернуться в главное меню (после столкновения)'),
        ]

        start_y = SCREEN_HEIGHT - 160
        for key, desc in controls:
            arcade.draw_text(key, SCREEN_WIDTH // 2 - 350, start_y,
                             arcade.color.CYAN, 20, anchor_x='left')
            arcade.draw_text('--', SCREEN_WIDTH // 2 - 220, start_y,
                             arcade.color.WHITE, 20, anchor_x='left')
            arcade.draw_text(desc, SCREEN_WIDTH // 2 - 150, start_y,
                             arcade.color.WHITE, 20, anchor_x='left')
            start_y -= 50

        arcade.draw_text('Нажмите ESC, чтобы вернуться', SCREEN_WIDTH // 2, 60,
                         arcade.color.LIGHT_GRAY, 18, anchor_x='center')

    def on_key_press(self, key, modifiers):
        if key == arcade.key.ESCAPE:
            self.window.show_view(self.previous_view)


class MenuView(arcade.View):
    def on_show_view(self):
        self.backgrounds = background.ParallaxGroup()

        bg_layer_size_px = (SCREEN_WIDTH, SCREEN_HEIGHT)

        self.backgrounds.add_from_file(
            ':resources:/images/miami_synth_parallax/layers/back.png',
            size=bg_layer_size_px,
            depth=10.0,
            scale=PIXEL_SCALE
        )
        self.backgrounds.add_from_file(
            ':resources:/images/miami_synth_parallax/layers/buildings.png',
            size=bg_layer_size_px,
            depth=5.0,
            scale=PIXEL_SCALE
        )
        self.backgrounds.add_from_file(
            ':resources:/images/miami_synth_parallax/layers/palms.png',
            size=bg_layer_size_px,
            depth=3.0,
            scale=PIXEL_SCALE
        )
        self.backgrounds.add_from_file(
            ':resources:/images/miami_synth_parallax/layers/highway.png',
            size=bg_layer_size_px,
            depth=1.0,
            scale=PIXEL_SCALE
        )

    def on_draw(self):
        self.clear()

        # Фон
        self.backgrounds.draw()

        arcade.draw_text('Miami Racer',
                         self.window.width // 2,
                         self.window.height // 2 + 60,
                         arcade.color.WHITE, 40,
                         anchor_x='center')

        arcade.draw_text('Нажмите ENTER для старта',
                         self.window.width // 2,
                         self.window.height // 2 - 20,
                         arcade.color.WHITE, 25,
                         anchor_x='center')

        arcade.draw_text('ESC — управление и инструкция',
                         self.window.width // 2,
                         self.window.height // 2 - 70,
                         arcade.color.LIGHT_GRAY, 18,
                         anchor_x='center')

    def on_key_press(self, key, modifiers):
        if key == arcade.key.ENTER:
            game_view = Game()
            self.window.show_view(game_view)
        elif key == arcade.key.ESCAPE:
            instruction = Instruction(self)
            self.window.show_view(instruction)


class Game(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.LAVENDER_PURPLE)

        self.db = Database()
        self.best_score = self.db.get_best_score()
        self.new_record = False

        # Спрайт машины
        self.player = arcade.Sprite(
            ':resources:/images/miami_synth_parallax/car/car-idle.png',
            scale=1.5
        )
        self.player.center_x = 150
        self.player.center_y = LANE_2_Y
        self.player.width = self.player.width / 2
        self.player.height = self.player.height / 2

        self.current_lane = 1
        self.all_sprites = arcade.SpriteList()
        self.obstacles = arcade.SpriteList()
        self.coins = arcade.SpriteList()
        self.star_coins = arcade.SpriteList()
        self.all_sprites.append(self.player)

        self.score = 0
        self.game_over = False

        self.paused = False
        self.is_dashing = False
        self.dash_timer = 0
        self.dash_cd = 0

        self.obstacle_timer = 0

        self.time = 0.0

        # Множитель
        self.multiplier = 1
        self.multiplier_timer = 0.0
        self.total_coins = 0
        self.star_unlocked = False

        # Звук монеты
        self.coin_sound = arcade.load_sound(':resources:/sounds/coin1.wav')
        self.star_sound = arcade.load_sound(':resources:/sounds/upgrade5.wav')

        # Частицы для рывка
        self.emitter = None

    def speed(self):
        # Возрастание скорости
        speed = 5.0 + (self.time / 10.0) * 0.5
        return min(speed, 15.0)

    def on_draw(self):
        self.clear()

        # Дорога
        for y_low, y_high in [(100, 200), (250, 350), (400, 500)]:
            arcade.draw_lrbt_rectangle_filled(0, SCREEN_WIDTH, y_low, y_high, arcade.color.DARK_GRAY)

        # Разделительные линии
        arcade.draw_line(0, (LANE_1_Y + LANE_2_Y) // 2, SCREEN_WIDTH, (LANE_1_Y + LANE_2_Y) // 2, arcade.color.WHITE,
                         3)
        arcade.draw_line(0, (LANE_2_Y + LANE_3_Y) // 2, SCREEN_WIDTH, (LANE_2_Y + LANE_3_Y) // 2, arcade.color.WHITE,
                         3)

        self.obstacles.draw()
        self.coins.draw()
        self.star_coins.draw()

        # Частицы позади игрока
        if self.emitter:
            self.emitter.draw()

        self.all_sprites.draw()

        # Счет
        arcade.draw_text(f'Монеты: {self.score}', 10, SCREEN_HEIGHT - 30, arcade.color.WHITE, 20)
        arcade.draw_text(f'Рекорд: {self.best_score}', 10, SCREEN_HEIGHT - 60, arcade.color.YELLOW, 20)

        # Множитель
        if self.multiplier == 3:
            arcade.draw_text(f'x3 БОНУС! {self.multiplier_timer:.1f}с', SCREEN_WIDTH // 2, SCREEN_HEIGHT - 80,
                             arcade.color.RED, 22, anchor_x='center')

        # Скорость
        speed_level = int((self.speed() - 5.0) / 0.5) + 1
        arcade.draw_text(f'Скорость: {speed_level}', SCREEN_WIDTH - 160, SCREEN_HEIGHT - 30, arcade.color.WHITE, 18)

        # КД рывка
        if self.dash_cd > 0:
            arcade.draw_text(f'Рывок: {self.dash_cd:.1f}с', 10, SCREEN_HEIGHT - 90, arcade.color.ORANGE, 15)
        else:
            arcade.draw_text('Рывок ГОТОВ (Shift)', 10, SCREEN_HEIGHT - 90, arcade.color.GREEN, 15)

        if self.paused:
            arcade.draw_text('ПАУЗА', SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2, arcade.color.WHITE, 50, anchor_x='center')
            arcade.draw_text('Нажмите SPACE, чтобы продолжить', SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50,
                             arcade.color.WHITE, 20, anchor_x='center')

        if self.game_over:
            if self.new_record:
                arcade.draw_text('НОВЫЙ РЕКОРД!', SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80, arcade.color.GOLD, 40,
                                 anchor_x='center')
            arcade.draw_text('СТОЛКНОВЕНИЕ!', SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 20,
                             arcade.color.RED, 30, anchor_x='center')
            arcade.draw_text('R - Перезапуск | ESC - Главное меню', SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 20,
                             arcade.color.WHITE, 20, anchor_x='center')

    def on_key_press(self, key, modifiers):
        # Пауза
        if key == arcade.key.SPACE and not self.game_over:
            self.paused = not self.paused
            return

        if self.paused:
            return

        if self.game_over:
            if key == arcade.key.R:
                self.reset_game()
            elif key == arcade.key.ESCAPE:
                self.db.close()
                menu_view = MenuView()
                self.window.show_view(menu_view)
            return

        # Переход между полосами
        if key == arcade.key.W:
            if self.current_lane < 2:
                self.current_lane += 1
                self.update_position()

        elif key == arcade.key.UP:
            if self.current_lane < 2:
                self.current_lane += 1
                self.update_position()

        elif key == arcade.key.S:
            if self.current_lane > 0:
                self.current_lane -= 1
                self.update_position()

        elif key == arcade.key.DOWN:
            if self.current_lane > 0:
                self.current_lane -= 1
                self.update_position()

        # Работа рывка
        elif key == arcade.key.LSHIFT and not self.is_dashing:
            if self.dash_cd <= 0:
                self.is_dashing = True
                self.dash_timer = 1.0
                self.dash_cd = 5.0
                self.dash_emitter()

        elif key == arcade.key.RSHIFT and not self.is_dashing:
            if self.dash_cd <= 0:
                self.is_dashing = True
                self.dash_timer = 1.0
                self.dash_cd = 5.0
                self.dash_emitter()

    def dash_emitter(self):
        # Частицы позади машины во время рывка
        self.emitter = Emitter(
            center_xy=(self.player.center_x - 30, self.player.center_y),
            emit_controller=EmitInterval(0.01),
            particle_factory=lambda e: FadeParticle(
                filename_or_texture=PARTICLE_TEX,
                change_xy=(-random.uniform(2, 5), random.uniform(-1.5, 1.5)),
                lifetime=random.uniform(0.3, 0.6),
                start_alpha=255,
                end_alpha=0,
                scale=random.uniform(0.4, 0.7),
            )
        )

    def update_position(self):
        lanes = [LANE_1_Y, LANE_2_Y, LANE_3_Y]
        self.player.center_y = lanes[self.current_lane]

    def occupied_lanes(self, x, space=60):
        occupied = set()
        lanes = [LANE_1_Y, LANE_2_Y, LANE_3_Y]
        for obstacle in self.obstacles:
            if abs(obstacle.center_x - x) < space:
                for i, lane_y in enumerate(lanes):
                    if abs(obstacle.center_y - lane_y) < 30:
                        occupied.add(i)
        return occupied

    def on_update(self, d_time):
        if self.game_over or self.paused:
            return

        self.time += d_time

        if self.is_dashing:
            self.dash_timer -= d_time
            if self.dash_timer <= 0:
                self.is_dashing = False
                self.emitter = None

        if self.dash_cd > 0:
            self.dash_cd -= d_time

        if self.emitter and self.is_dashing:
            self.emitter.center_x = self.player.center_x - 30
            self.emitter.center_y = self.player.center_y
            self.emitter.update()

        current_speed = self.speed()
        if self.is_dashing:
            current_speed *= 2.0

        self.obstacle_timer += d_time

        for obstacle in self.obstacles:
            obstacle.center_x -= current_speed
            if obstacle.center_x < -50:
                obstacle.remove_from_sprite_lists()

        for coin in self.coins:
            coin.center_x -= current_speed
            if coin.center_x < -50:
                coin.remove_from_sprite_lists()

        for star in self.star_coins:
            star.center_x -= current_speed
            if star.center_x < -50:
                star.remove_from_sprite_lists()

        # Таймер множителя
        if self.multiplier_timer > 0:
            self.multiplier_timer -= d_time
            if self.multiplier_timer <= 0:
                self.multiplier = 1
                self.multiplier_timer = 0

        if self.time >= 3.0:
            if self.obstacle_timer >= 2.0:
                self.spawn_obstacles()
                self.obstacle_timer = 0

            if random.random() < 0.01:
                self.spawn_coin()

            # Множитель появляется только после сбора 20 монет
            if self.star_unlocked:
                star_chance = 0.001
            elif self.total_coins >= 20:
                self.star_unlocked = True
                star_chance = 0.01
            else:
                star_chance = 0.0

            if star_chance > 0 and random.random() < star_chance:
                self.spawn_star_coin()

        # Столкновение
        if arcade.check_for_collision_with_list(self.player, self.obstacles):
            self.end_game()

        collected_coins = arcade.check_for_collision_with_list(self.player, self.coins)
        for coin in collected_coins:
            coin.remove_from_sprite_lists()
            self.score += self.multiplier
            self.total_coins += 1
            if self.total_coins >= 20:
                self.star_unlocked = True
            arcade.play_sound(self.coin_sound)

        collected_stars = arcade.check_for_collision_with_list(self.player, self.star_coins)
        for star in collected_stars:
            star.remove_from_sprite_lists()
            self.multiplier = 3
            self.multiplier_timer = 5.0
            arcade.play_sound(self.star_sound)

    def spawn_obstacles(self):
        free_lane = random.choice([0, 1, 2])
        lanes = [LANE_1_Y, LANE_2_Y, LANE_3_Y]
        for i, lane_y in enumerate(lanes):
            if i != free_lane:
                obstacle = arcade.Sprite(':resources:/images/tiles/boxCrate_double.png', scale=0.5)
                obstacle.center_x = SCREEN_WIDTH + 50
                obstacle.center_y = lane_y
                self.obstacles.append(obstacle)

    def spawn_coin(self):
        coin_x = SCREEN_WIDTH + 50
        occupied = self.occupied_lanes(coin_x, space=80)
        free_lanes = [i for i in range(3) if i not in occupied]
        if not free_lanes:
            return
        lane = random.choice(free_lanes)
        lanes = [LANE_1_Y, LANE_2_Y, LANE_3_Y]
        coin = arcade.Sprite(':resources:/images/items/coinGold.png', scale=0.5)
        coin.center_x = coin_x
        coin.center_y = lanes[lane]
        self.coins.append(coin)

    def spawn_star_coin(self):
        star_x = SCREEN_WIDTH + 50
        occupied = self.occupied_lanes(star_x, space=80)
        free_lanes = [i for i in range(3) if i not in occupied]
        if not free_lanes:
            return
        lane = random.choice(free_lanes)
        lanes = [LANE_1_Y, LANE_2_Y, LANE_3_Y]
        star = arcade.Sprite(':resources:/images/items/star.png', scale=0.6)
        star.center_x = star_x
        star.center_y = lanes[lane]
        self.star_coins.append(star)

    def end_game(self):
        self.game_over = True
        self.is_dashing = False
        self.emitter = None
        self.db.add_score(self.score)
        if self.score > self.best_score:
            self.best_score = self.score
            self.new_record = True

    def reset_game(self):
        self.obstacles.clear()
        self.coins.clear()
        self.star_coins.clear()
        self.score = 0
        self.game_over = False
        self.paused = False
        self.new_record = False
        self.current_lane = 1
        self.player.center_y = LANE_2_Y
        self.obstacle_timer = 0
        self.time = 0.0
        self.multiplier = 1
        self.multiplier_timer = 0.0
        self.total_coins = 0
        self.star_unlocked = False

        self.is_dashing = False
        self.dash_cd = 0
        self.emitter = None

    def on_hide_view(self):
        self.db.close()


def main():
    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    menu_view = MenuView()
    window.show_view(menu_view)
    arcade.run()


if __name__ == '__main__':
    main()
